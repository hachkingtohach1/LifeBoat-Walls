<?php

namespace walls\language;

use LbCore\language\core\German as LbGerman;

/**
 * Contains translated string specifically for Walls game on German
 */
class German extends LbGerman {

	public function __construct() {
		$this->translates["WALLS_DROPPED"] = "Die Wände sind gefallen!";
		$this->translates["GAME_STARTED"] = "Das Spiel hat begonnen!";
		$this->translates["TEAM_CHAT_ENABLED"] = "Team-Chat aktiviert.";
		$this->translates["USING_MAP"] = "Benutze Map";
		$this->translates["DEATHMATCH_STARTED"] = "Deathmatch hat begonnen!";
		$this->translates["WON_THE_MATCH"] = "hat das Match gewonnen.";
		$this->translates["RETURNING_TO_LOBBY"] = "Kehre zur Lobby zurück...";
		$this->translates["WAS_SLAIN_BY"] = "wurde getötet von";
		$this->translates["YOU_ALREADY_ON_THE"] = "Du bist schon in dem";
		$this->translates["TEAM"] = "Team";
		$this->translates["TEAM_IS_FULL"] = "Das Team ist schon voll.";
		$this->translates["YOU_JOINED_THE"] = "Du betrittst";
		$this->translates["YOU_NOW_SPECTATING"] = "Du schaust nun zu.";
		$this->translates["LOBBY_RETURN"] = "Um zur Lobby zurückzukehren, benutze /lobby.";
		$this->translates["DISCONNECTED"] = "getrennt";
		$this->translates["HEIGHT_LIMIT_RICHED"] = "Du hast die maximale Bauhöhe erreicht.";
		$this->translates["DONT_BREAK_WALL"] = "Versuche nicht, die Wand zu zerstören.";
		$this->translates["SECONDS"] = "Sekunde(n)";
		$this->translates["STARTING_IN"] = "Starte in";
		$this->translates["RETURNING_TO_LOBBY_IN"] = "Kehre zur Lobby zurück in";
		$this->translates["WAITING_FOR"] = "Warte auf";
		$this->translates["PLAYERS"] = "Spieler";
		$this->translates["DROP"] = "Drop";
		$this->translates["DEATHMATCH"] = "Deathmatch";
		$this->translates["END"] = "Ende";
		$this->translates["LOBBY_TO_RETURN"] = "Lobby zum zurückkehren";
		$this->translates["RED"] = "ROT";
		$this->translates["BLUE"] = "BLAU";
		$this->translates["GREEN"] = "GRÜN";
		$this->translates["YELLOW"] = "GELB";
		$this->translates["WALLS_WILL_DROP_IN"] = "Die Wände fallen in";
		$this->translates["MINUTES"] = "Minute(n)";
		$this->translates["DEATHMATCH_IN"] = "Deathmatch in";
		$this->translates["DEATHMATCH_WILL_END_IN"] = "Deathmatch endet in";
		$this->translates["PLAYERS_ONLINE"] = "Spieler online";
		$this->translates["DRAW"] = "Zeichne";
		$this->translates["WAIT_MATCH_ENDS"] = "Bitte warten Sie, bis die aktuelle Begegnung endete.";
	
	}

}
