<?php

namespace walls\language;

use LbCore\language\core\Dutch as LbDutch;

/**
 * Contains translated string specifically for Walls game on Dutch
 */
class Dutch extends LbDutch {

	public function __construct() {
		$this->translates = array_merge($this->translates, array(
			'WALLS_DROPPED' => 'De muren zijn gedaald!',
			'GAME_STARTED' => 'De wedstrijd is begonnen!',
			'TEAM_CHAT_ENABLED' => 'Team Chat ingeschakeld.',
			'USING_MAP' => 'Door de kaart',
			'DEATHMATCH_STARTED' => 'Deathmatch is begonnen!',
			'WON_THE_MATCH' => 'won de wedstrijd.',
			'RETURNING_TO_LOBBY' => 'Terugkerend naar lobbyen...',
			'WAS_SLAIN_BY' => 'werd gedood door',
			'YOU_ALREADY_ON_THE' => 'Je bent al op de',
			'TEAM' => 'team',
			'TEAM_IS_FULL' => 'Dat team is al vol.',
			'YOU_JOINED_THE' => 'U toegetreden tot de',
			'YOU_NOW_SPECTATING' => 'Battle in progress. Je bent nu een toeschouwer.',
			'WILL_JOIN_NEXT' => 'Je komt terecht in het volgende gevecht.',
			'DISCONNECTED' => 'losgekoppeld',
			'HEIGHT_LIMIT_RICHED' => 'Je hebt de opbouw hoogte limiet bereikt.',
			'DONT_BREAK_WALL' => 'Probeer niet om de muur te breken.',
			'SECONDS' => 'seconde(n)',
			'STARTING_IN' => 'Vanaf',
			'RETURNING_TO_LOBBY_IN' => 'Terugkeren om te lobbyen in',
			'WAITING_FOR' => 'Wachten op',
			'PLAYERS' => 'speler(s)',
			'DROP' => 'Drop',
			'DEATHMATCH' => 'Deathmatch',
			'END' => 'Einde',
			'LOBBY_TO_RETURN' => 'lobbyen om terug te keren',
			'RED' => 'ROOD',
			'BLUE' => 'BLAUW',
			'GREEN' => 'GROEN',
			'YELLOW' => 'GEEL',
			'WALLS_WILL_DROP_IN' => 'De muren zal dalen in ',
			'MINUTES' => 'notulen',
			'DEATHMATCH_IN' => 'Deathmatch in ',
			'DEATHMATCH_WILL_END_IN' => 'Deathmatch zal eindigen in ',
			'PLAYERS_ONLINE' => 'Spelers online',
			'DRAW' => 'Trekken',
            'WAIT_MATCH_ENDS' => 'Wacht tot de huidige eindstand.'
		));
	}

}
